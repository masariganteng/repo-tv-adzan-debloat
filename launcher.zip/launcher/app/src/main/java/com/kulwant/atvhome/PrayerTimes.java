package com.kulwant.atvhome;

import java.util.Calendar;
import java.util.TimeZone;

/**
 * Daily prayer times computed offline (no network, no API): sun position from the standard
 * astronomical formulas, as in praytimes.org. Defaults match Kemenag RI: Fajr 20 deg, Isha 18 deg,
 * Asr with shadow factor 1 (Shafi'i), plus a few minutes of ihtiyath on every time.
 */
final class PrayerTimes {

    static final String[] NAMES = {"Subuh", "Dzuhur", "Ashar", "Maghrib", "Isya"};

    private final double lat, lng, fajrAngle, ishaAngle;
    private final int ihtiyathMin;

    PrayerTimes(double lat, double lng, double fajrAngle, double ishaAngle, int ihtiyathMin) {
        this.lat = lat;
        this.lng = lng;
        this.fajrAngle = fajrAngle;
        this.ishaAngle = ishaAngle;
        this.ihtiyathMin = ihtiyathMin;
    }

    /** Epoch millis of Subuh, Dzuhur, Ashar, Maghrib, Isya on the given local day. */
    long[] forDay(Calendar day) {
        int y = day.get(Calendar.YEAR), m = day.get(Calendar.MONTH) + 1, d = day.get(Calendar.DAY_OF_MONTH);
        double tz = TimeZone.getDefault().getOffset(day.getTimeInMillis()) / 3600000.0;
        double jd = julian(y, m, d) - lng / (15 * 24.0);

        // two passes: the sun's position is evaluated at the time of each prayer
        double[] t = {5 / 24.0, 12 / 24.0, 13 / 24.0, 18 / 24.0, 18 / 24.0};
        double[] h = new double[5];
        for (int pass = 0; pass < 2; pass++) {
            h[0] = angleTime(jd, t[0], fajrAngle, true);
            h[1] = midDay(jd, t[1]);
            h[2] = asrTime(jd, t[2], 1);
            h[3] = angleTime(jd, t[3], 0.833, false);
            h[4] = angleTime(jd, t[4], ishaAngle, false);
            for (int i = 0; i < 5; i++) t[i] = h[i] / 24.0;
        }

        Calendar midnight = (Calendar) day.clone();
        midnight.set(Calendar.HOUR_OF_DAY, 0);
        midnight.set(Calendar.MINUTE, 0);
        midnight.set(Calendar.SECOND, 0);
        midnight.set(Calendar.MILLISECOND, 0);
        long[] out = new long[5];
        for (int i = 0; i < 5; i++) {
            double local = h[i] + tz - lng / 15.0;
            long ms = Math.round(local * 3600000.0) + ihtiyathMin * 60000L;
            // round up to the next whole minute, as printed schedules do
            ms = (ms + 59_999) / 60_000 * 60_000;
            out[i] = midnight.getTimeInMillis() + ms;
        }
        return out;
    }

    // ---------------------------------------------------------------- astronomy

    private static double[] sun(double jd) {
        double D = jd - 2451545.0;
        double g = fix(357.529 + 0.98560028 * D, 360);
        double q = fix(280.459 + 0.98564736 * D, 360);
        double L = fix(q + 1.915 * sin(g) + 0.020 * sin(2 * g), 360);
        double e = 23.439 - 0.00000036 * D;
        double ra = Math.toDegrees(Math.atan2(cos(e) * sin(L), cos(L))) / 15.0;
        double eqt = q / 15.0 - fix(ra, 24);
        double decl = Math.toDegrees(Math.asin(sin(e) * sin(L)));
        return new double[]{decl, eqt};
    }

    private double midDay(double jd, double t) {
        return fix(12 - sun(jd + t)[1], 24);
    }

    private double angleTime(double jd, double t, double angle, boolean ccw) {
        double decl = sun(jd + t)[0];
        double x = (-sin(angle) - sin(decl) * sin(lat)) / (cos(decl) * cos(lat));
        double a = Math.toDegrees(Math.acos(Math.max(-1, Math.min(1, x)))) / 15.0;
        return midDay(jd, t) + (ccw ? -a : a);
    }

    private double asrTime(double jd, double t, double factor) {
        double decl = sun(jd + t)[0];
        double angle = -Math.toDegrees(Math.atan(1.0 / (factor + Math.tan(Math.toRadians(Math.abs(lat - decl))))));
        return angleTime(jd, t, angle, false);
    }

    private static double julian(int y, int m, int d) {
        if (m <= 2) {
            y -= 1;
            m += 12;
        }
        double a = Math.floor(y / 100.0);
        double b = 2 - a + Math.floor(a / 4.0);
        return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + b - 1524.5;
    }

    private static double fix(double a, double mode) {
        a = a - mode * Math.floor(a / mode);
        return a < 0 ? a + mode : a;
    }

    private static double sin(double deg) { return Math.sin(Math.toRadians(deg)); }

    private static double cos(double deg) { return Math.cos(Math.toRadians(deg)); }
}
